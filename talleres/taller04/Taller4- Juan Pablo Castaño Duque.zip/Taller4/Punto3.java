
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Punto3
{
 
public static int[] Ordenar (int  [] x){
       for (int i =0 ; i<x.length; i++) {
           int menor = x [i];
           for (int j=0; j<x.length; j++){
               if( x[j] < menor) {
                   menor = x [j];
                   int d = x [i];
                   x [i] = x [j];
                   x [j] = d;
                }
            }
        }
        return x;
    }
                   
 

public static int[] generarArregloDeTamanoN(int n){
  int max = 5000;
  int[] array = new int[n];
  Random generator = new Random();
  for (int i =0; i<n; i++)
     array[i] = generator.nextInt(max);
  return array;
}

public static void main(String[] args){
  for(int i = 10000; i <= 100000; i = i + 10000)
    System.out.println(i+" "+tomarTiempo(i));
}

public static long tomarTiempo(int n){
  int[] a = generarArregloDeTamanoN(n);
  long startTime = System.currentTimeMillis();
  Ordenar(a);
  long estimatedTime = System.currentTimeMillis() - startTime;
  return estimatedTime;
}

}