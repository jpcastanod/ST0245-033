
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Punto2
{
 
public static void multiplicar (int  x){
     for (int i = 0; i<x; i++) {
         for (int j=0 ; j<x; j++) {
           
    }
                   
}
}

 

public static int generarArregloDeTamanoN(int n){
  int max = 5000;
  int[] array = new int[n];
  Random generator = new Random();
  for (int i =0; i<n; i++)
     array[i] = generator.nextInt(max);
  return n;
}

public static void main(String[] args){
  for(int i = 10000; i <= 1000000; i = i+10000)
    System.out.println(i+" "+tomarTiempo(i));
}

public static long tomarTiempo(int n){
  int a = generarArregloDeTamanoN(n);
  long startTime = System.currentTimeMillis();
  multiplicar(a);
  long estimatedTime = System.currentTimeMillis() - startTime;
  return estimatedTime;
}

}