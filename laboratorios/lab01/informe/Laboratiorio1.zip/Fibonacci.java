
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Fibonacci
{
 
 public static int Fibonacci(int n)
  {
     int result;
     if (n == 0 || n == 1)
       result = n;
     else
       result = Fibonacci(n-1) + Fibonacci(n-2);
     return result;
  }

public static int[] generarArregloDeTamanoN(int n){
  int max = 5000;
  int[] array = new int[n];
  Random generator = new Random();
  for (int i =0; i<n; i++)
     array[i] = generator.nextInt(max);
  return array;
}

public static void main(String[] args){
  for(int i = 1; i <= 10; i = i + 1)
    System.out.println(i+" "+tomarTiempo(i));
}

public static long tomarTiempo(int n){
  int[] a = generarArregloDeTamanoN(n);
  long startTime = System.currentTimeMillis();
  Fibonacci( n);
  long estimatedTime = System.currentTimeMillis() - startTime;
  return estimatedTime;
}

}