
/**
 * Write a description of class Codingbat2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Codingbat2
{
    public boolean groupSum(int start, int[] nums, int target) {
    if (start >= nums.length) return target == 0;
    return groupSum(start + 1, nums, target - nums[start])
            || groupSum(start + 1, nums, target);
}
public boolean groupSum6(int start, int[] nums, int target) {
    if (start >= nums.length) return target == 0;
    if (nums[start] == 6)
        return groupSum6(start + 1, nums, target - nums[start]);
    return groupSum6(start + 1, nums, target - nums[start])
            || groupSum6(start + 1, nums, target);
}
public boolean groupNoAdj(int start, int[] nums, int target) {
    if (start >= nums.length) return target == 0;
    return groupNoAdj(start + 2, nums, target - nums[start])
            || groupNoAdj(start + 1, nums, target);
}
public boolean groupSum5(int start, int[] nums, int target) {
    if (start >= nums.length) return target == 0;
    if (nums[start] % 5 == 0) {
        if (start < nums.length - 1 && nums[start + 1] == 1)
            return groupSum5(start + 2, nums, target - nums[start]);
        return groupSum5(start + 1, nums, target - nums[start]);
    }
    return groupSum5(start + 1, nums, target - nums[start])
            || groupSum5(start + 1, nums, target);
}
public boolean splitArray(int[] nums) {
    return helper(0, nums, 0, 0);
}
 
private boolean helper(int start, int[] nums, int sum1, int sum2) {
    if (start >= nums.length) return sum1 == sum2;
    return helper(start + 1, nums, sum1 + nums[start], sum2)
            || helper(start + 1, nums, sum1, sum2 + nums[start]);
}
}
