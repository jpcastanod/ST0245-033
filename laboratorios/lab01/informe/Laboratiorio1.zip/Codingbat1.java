
/**
 * Write a description of class Codingbat1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Codingbat1
{
   public  int factorial(int n) {
  if (n == 1 || n ==0){ 
  return n;
  }
  else{
    return n*factorial (n-1);
  }
  
}
public  int bunnyEars(int bunnies) {
  if (bunnies ==0){
  return 0; 
  }
  else {
    return 2 + bunnyEars (bunnies-1);
  }
}
public   int fibonacci(int n) {
  if (n == 0 || n==1){
    return n;
  }
  else {
    return fibonacci(n-1) + fibonacci (n-2);
  }
}
public  int count7(int n) {
  if (n<6) {
    return 0;
  }
  else if (n%10 ==7) {
   return 1 + count7 (n/10);
    }
    else return count7 (n/10);
}
public int powerN(int base, int n) {
  if (n==1) {
    return base;
  }
  else return base * powerN (base , n-1);
}



}
